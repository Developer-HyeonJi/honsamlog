create
    definer = hyunji@`%` procedure insert_dummy_comments()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 100 DO
            INSERT INTO tb_comment (post_id, content, writer, delete_yn, created_date, modified_date)
            VALUES (990, CONCAT('테스트 댓글 ', i), '홍길동', 0, NOW(), NULL);
            SET i = i + 1;
        END WHILE;
END;

